from __future__ import annotations

import json
import subprocess
import time
from pathlib import Path

ROOT = Path.cwd()
RESPONSIVE_TEST = 'import { expect, test, type Page } from "@playwright/test";\n\nconst expectNoHorizontalOverflow = async (page: Page) => {\n\tconst dimensions = await page.evaluate(() => ({\n\t\tinnerWidth: window.innerWidth,\n\t\tscrollWidth: document.documentElement.scrollWidth,\n\t}));\n\texpect(dimensions.scrollWidth).toBeLessThanOrEqual(dimensions.innerWidth);\n};\n\nconst expectVisibleTargetsUsable = async (page: Page) => {\n\tconst failures = await page.evaluate(() => {\n\t\tconst selectors = [\n\t\t\t"button",\n\t\t\t"select",\n\t\t\t\'input[type="file"]\',\n\t\t\t\'input[type="range"]\',\n\t\t\t".toggle-control",\n\t\t\t"a[href]",\n\t\t].join(",");\n\t\treturn Array.from(document.querySelectorAll<HTMLElement>(selectors))\n\t\t\t.map((element) => {\n\t\t\t\tconst rect = element.getBoundingClientRect();\n\t\t\t\treturn {\n\t\t\t\t\tlabel:\n\t\t\t\t\t\telement.getAttribute("aria-label") ??\n\t\t\t\t\t\telement.textContent?.trim().slice(0, 80) ??\n\t\t\t\t\t\telement.tagName,\n\t\t\t\t\theight: rect.height,\n\t\t\t\t\twidth: rect.width,\n\t\t\t\t\tleft: rect.left,\n\t\t\t\t\tright: rect.right,\n\t\t\t\t\ttop: rect.top,\n\t\t\t\t\tbottom: rect.bottom,\n\t\t\t\t};\n\t\t\t})\n\t\t\t.filter(\n\t\t\t\t(target) =>\n\t\t\t\t\ttarget.width > 0 &&\n\t\t\t\t\ttarget.height > 0 &&\n\t\t\t\t\ttarget.bottom > 0 &&\n\t\t\t\t\ttarget.top < window.innerHeight &&\n\t\t\t\t\t(target.width < 24 ||\n\t\t\t\t\t\ttarget.height < 24 ||\n\t\t\t\t\t\ttarget.left < -0.5 ||\n\t\t\t\t\t\ttarget.right > window.innerWidth + 0.5),\n\t\t\t);\n\t});\n\texpect(failures).toEqual([]);\n};\n\ntest("workspace reflows across compact portrait, landscape, desktop, and 4K viewports", async ({\n\tpage,\n}) => {\n\tawait page.goto("/");\n\tfor (const viewport of [\n\t\t{ width: 320, height: 568 },\n\t\t{ width: 568, height: 320 },\n\t\t{ width: 375, height: 667 },\n\t\t{ width: 667, height: 375 },\n\t\t{ width: 768, height: 1024 },\n\t\t{ width: 1024, height: 768 },\n\t\t{ width: 1440, height: 900 },\n\t\t{ width: 1920, height: 1080 },\n\t\t{ width: 3840, height: 2160 },\n\t]) {\n\t\tawait page.setViewportSize(viewport);\n\t\tawait expectNoHorizontalOverflow(page);\n\t\tawait expect(\n\t\t\tpage.getByRole("heading", { name: "OmniConvert", exact: true }),\n\t\t).toBeVisible();\n\t\tawait expect(\n\t\t\tpage.getByRole("heading", { name: "Import files", exact: true }),\n\t\t).toBeVisible();\n\t}\n});\n\ntest("200% text size keeps a 320px workspace, long filename, actions, and preview fully usable", async ({\n\tpage,\n}) => {\n\tawait page.setViewportSize({ width: 320, height: 700 });\n\tawait page.goto("/");\n\tawait page.evaluate(() => {\n\t\tdocument.documentElement.style.fontSize = "32px";\n\t});\n\tawait expectNoHorizontalOverflow(page);\n\tawait expectVisibleTargetsUsable(page);\n\n\tconst longName = `${"very-long-local-file-name-".repeat(7)}data.csv`;\n\tawait page.locator(\'input[type="file"]\').setInputFiles({\n\t\tname: longName,\n\t\tmimeType: "text/csv",\n\t\tbuffer: Buffer.from("name,value\\nAda,42"),\n\t});\n\tconst card = page.locator(".job-card");\n\tawait expect(card).toBeVisible();\n\tawait expectNoHorizontalOverflow(page);\n\tawait expectVisibleTargetsUsable(page);\n\n\tawait card.locator("select").selectOption("json");\n\tawait card.getByRole("button", { name: "Convert", exact: true }).click();\n\tawait expect(card).toHaveAttribute("data-status", "completed");\n\tawait expectNoHorizontalOverflow(page);\n\n\tawait card.getByRole("button", { name: "Preview", exact: true }).click();\n\tconst dialog = page.getByRole("dialog", { name: "Preview" });\n\tawait expect(dialog).toBeVisible();\n\tconst bounds = await dialog.boundingBox();\n\texpect(bounds).not.toBeNull();\n\texpect(bounds?.x ?? -1).toBeGreaterThanOrEqual(0);\n\texpect((bounds?.x ?? 0) + (bounds?.width ?? 0)).toBeLessThanOrEqual(320.5);\n\tawait expectNoHorizontalOverflow(page);\n\tawait expectVisibleTargetsUsable(page);\n});\n\ntest("short landscape viewports keep metadata dialog inside the visual viewport with reachable controls", async ({\n\tpage,\n}) => {\n\tawait page.setViewportSize({ width: 568, height: 256 });\n\tawait page.goto("/");\n\tawait page.locator(\'input[type="file"]\').setInputFiles({\n\t\tname: "compact.csv",\n\t\tmimeType: "text/csv",\n\t\tbuffer: Buffer.from("name,value\\nAda,42"),\n\t});\n\tconst card = page.locator(".job-card");\n\tawait expect(card).toBeVisible();\n\tawait card.getByRole("button", { name: /Metadata/ }).click();\n\tconst dialog = page.getByRole("dialog", { name: "Metadata" });\n\tawait expect(dialog).toBeVisible();\n\tconst bounds = await dialog.boundingBox();\n\texpect(bounds).not.toBeNull();\n\texpect(bounds?.x ?? -1).toBeGreaterThanOrEqual(0);\n\texpect(bounds?.y ?? -1).toBeGreaterThanOrEqual(0);\n\texpect((bounds?.x ?? 0) + (bounds?.width ?? 0)).toBeLessThanOrEqual(568.5);\n\texpect((bounds?.y ?? 0) + (bounds?.height ?? 0)).toBeLessThanOrEqual(256.5);\n\tawait expectNoHorizontalOverflow(page);\n\tawait expectVisibleTargetsUsable(page);\n\tawait expect(dialog.getByRole("button", { name: /close/i })).toBeVisible();\n});\n'


def run(*args: str, check: bool = True, capture: bool = False) -> subprocess.CompletedProcess[str]:
    print("+", " ".join(args), flush=True)
    return subprocess.run(args, cwd=ROOT, text=True, check=check, capture_output=capture)


def replace_once(path: Path, old: str, new: str) -> None:
    text = path.read_text()
    if old not in text:
        raise RuntimeError(f"Missing anchor in {path}: {old[:100]!r}")
    path.write_text(text.replace(old, new, 1))


def apply_changes() -> None:
    css_path = Path("src/styles/tokens.css")
    css = css_path.read_text()
    replacements = {
        "  --workbench-width: clamp(20rem, 94vw, 120rem);": "  --workbench-width: min(94vw, 120rem);",
        "body {\n  min-width: 20rem;": "body {\n  min-width: 0;",
        """.job-actions {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-1);
  justify-content: flex-end;
}

.job-actions button {
  min-width: 6rem;
  padding-inline: 0.9rem;
}""": """.job-actions {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(min(100%, 8.5rem), 1fr));
  gap: var(--space-1);
}

.job-actions button {
  width: 100%;
  min-width: 0;
  padding-inline: 0.9rem;
  overflow-wrap: anywhere;
}""",
        """.metadata-drawer header,
.preview-modal > header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--space-2);
}""": """.metadata-drawer header,
.preview-modal > header {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--space-2);
  min-width: 0;
}""",
        """.metadata-drawer footer button,
.preview-modal > header button { min-width: 6rem; padding-inline: 0.85rem; }""": """.metadata-drawer footer button,
.preview-modal > header button { min-width: min(6rem, 100%); max-width: 100%; padding-inline: 0.85rem; overflow-wrap: anywhere; }""",
        ".release-update-modal footer button { min-width: 7rem; }": ".release-update-modal footer button { min-width: min(7rem, 100%); max-width: 100%; overflow-wrap: anywhere; }",
        ".job-actions { flex-wrap: wrap; gap: var(--space-1); }": ".job-actions { gap: var(--space-1); }",
    }
    for old, new in replacements.items():
        if old not in css:
            raise RuntimeError(f"Missing CSS anchor: {old[:100]!r}")
        css = css.replace(old, new, 1)

    insert_after = """button,
select,
input[type="file"] {
  min-height: 2.75rem;
}
"""
    addition = """

button,
select,
input[type="file"],
input[type="range"],
textarea {
  max-inline-size: 100%;
}

button,
.import-notice,
.job-progress-copy > :first-child,
.workbench-footnote {
  overflow-wrap: anywhere;
}

.workspace-toolbar > *,
.aggregate-progress-copy > *,
.job-progress-copy > *,
.queue-heading-row > *,
.job-card-header > * {
  min-width: 0;
}
"""
    if insert_after not in css:
        raise RuntimeError("Missing control-size insertion anchor")
    css = css.replace(insert_after, insert_after + addition, 1)

    short_landscape = """

@media (max-height: 30rem) {
  .metadata-drawer,
  .preview-modal,
  .release-update-modal {
    max-height: calc(100svh - 0.5rem);
  }

  .metadata-drawer {
    height: calc(100svh - 0.5rem);
  }
}
"""
    reduced_motion_anchor = "\n@media (prefers-reduced-motion: reduce) {"
    if reduced_motion_anchor not in css:
        raise RuntimeError("Missing reduced-motion anchor")
    css = css.replace(reduced_motion_anchor, short_landscape + reduced_motion_anchor, 1)
    css_path.write_text(css)

    package_path = Path("package.json")
    package = json.loads(package_path.read_text())
    if package.get("version") != "1.0.0":
        raise RuntimeError(f"Expected package version 1.0.0, got {package.get('version')}")
    package["version"] = "1.0.1"
    package_path.write_text(json.dumps(package, indent=2) + "\n")

    doc_paths = [
        Path("AGENTS.md"), Path("TODO.md"), Path("CHANGELOG.md"), Path("README.md"),
        Path("docs/HANDOFF.md"), Path("docs/verification.md"), Path("docs/production.md"),
    ]
    for path in doc_paths:
        path.write_text(path.read_text().replace("omniconvert-sfya", "omniconverttool"))

    replace_once(
        Path("AGENTS.md"),
        "- UI must remain usable from 320px through 3840px+, keyboard-complete, reduced-motion aware, and WCAG 2.2 AA-oriented.",
        "- UI must remain device/viewport agnostic: usable without lost information or functionality from 320px through 3840px+, portrait or landscape, keyboard/pointer/touch input, zoom-equivalent narrow viewports, and increased text sizing. Preserve keyboard completion, reduced-motion support, visible focus, >=24 CSS-pixel pointer targets (44px controls where practical), and WCAG 2.2 AA-oriented reflow. Never use device-model sniffing to choose layout.",
    )

    section = """### Device/viewport-agnostic responsive hardening — 2026-10-31
- Increment OmniConvert to `1.0.1` for the significant client UX update.
- Remove rem-scaled global minimum widths that caused horizontal overflow when users increased root text size; keep the workbench bounded by available viewport space instead of device assumptions.
- Make job actions container-responsive, wrap long notices/statuses and modal headers safely, constrain modal action widths, and use more of short landscape viewports while preserving native dialog scrolling/focus.
- Add a dedicated three-engine responsive regression suite covering 320px through 3840px, portrait/landscape, 200% text sizing, long filenames, >=24 CSS-pixel visible targets, and short-landscape dialogs. The test is RED-proven against the pre-fix source before implementation.
- Netlify project documentation now uses the renamed production project `omniconverttool`; live host verification is performed after the validated source is deployed.

"""
    replace_once(Path("CHANGELOG.md"), "## [Unreleased]\n\n", "## [Unreleased]\n\n" + section)

    phase22 = """## Current checkpoint
**IMPLEMENTED — Phase22 device/viewport-agnostic responsive hardening, awaiting permanent Validate and live-host verification (2026-10-31).** OmniConvert is now `1.0.1`. The responsive contract no longer couples page minimum width to root `rem` sizing; job actions adapt to their available container, long content wraps without widening the page, modal headers/actions stay bounded, and short landscape dialogs use available safe viewport height. A new `tests/e2e/responsive.spec.ts` regression is RED-proven against the prior `1.0.0` CSS and exercises compact portrait/landscape, 320–3840px widths, 200% root text size, long filenames, visible target sizing, and dialog bounds across Chromium/Firefox/WebKit. The integration gate must pass before this checkpoint is committed; permanent `Validate` and the deployed Netlify host contract remain separate gates.

Next action: confirm the `1.0.1` Netlify deploy for `https://omniconverttool.netlify.app`, run `pnpm release:verify-host -- https://omniconverttool.netlify.app` against the exact clean artifact, then trigger the permanent `Validate` workflow on the synchronized source before marking Phase22 COMPLETE.

### Historical Phase21 checkpoint
"""
    replace_once(Path("TODO.md"), "## Current checkpoint\n", phase22)
    replace_once(
        Path("TODO.md"),
        "| Handoff/tooling | Ignore outputs, distribution notes, durable handoff | COMPLETE |",
        "| 22 | Device/viewport-agnostic responsive hardening | IMPLEMENTED; permanent gate pending | `1.0.1`; RED-proven text-size reflow regression; three-engine responsive suite; live host verification pending. |\n| Handoff/tooling | Ignore outputs, distribution notes, durable handoff | COMPLETE |",
    )
    replace_once(
        Path("TODO.md"),
        "## File-creation checkpoint record\n",
        "## File-creation checkpoint record\nPhase22 creates one retained file, `tests/e2e/responsive.spec.ts`; the temporary integration workflow/script remove themselves in the implementation commit, keeping the checkpoint within the three-new-file ceiling. No dependency or ADR is added.\n\n",
    )

    readme = Path("README.md")
    text = readme.read_text()
    start = text.index("## Status\n") + len("## Status\n")
    end = text.index("\nThe complete original user-supplied product brief", start)
    status = """

OmniConvert is now version `1.0.1`. Phase22 hardens the client as a device/viewport-agnostic workbench: layout is governed by available space rather than device identity, reflows from 320 CSS pixels through 4K-class viewports in portrait and landscape, remains usable with increased text sizing, preserves >=24 CSS-pixel visible pointer targets (with 44px primary controls where practical), and keeps dialogs/actions bounded on compact landscape screens. A dedicated Chromium/Firefox/WebKit regression suite covers those boundaries. Netlify production is `https://omniconverttool.netlify.app`; the exact deployed artifact is verified separately from the source gate before Phase22 is marked complete.
"""
    readme.write_text(text[:start] + status + text[end:])

    note = """

Phase22 implementation candidate (`1.0.1`, 2026-10-31): a new responsive E2E regression first fails the prior source at 320 CSS pixels with 200% root text sizing because rem-scaled page minimums widen the document. The fix removes that global rem minimum, makes action/modal wrapping container-safe, and adds compact-landscape bounds. The new suite covers 320–3840px, both orientations, 200% text size, long filenames, visible >=24 CSS-pixel targets, and dialog containment across all three Playwright engines. Official design references rechecked this session: WCAG 2.2 SC 1.4.10 Reflow, 1.3.4 Orientation, 2.5.8 Target Size (Minimum), 2.4.11 Focus Not Obscured (Minimum), plus MDN responsive-design/viewport guidance. Permanent `Validate`, physical-device/manual AT evaluation, and live-host verification remain separate until they are actually run.
"""
    replace_once(Path("docs/verification.md"), "# Verification evidence — 2026-10-31\n", "# Verification evidence — 2026-10-31\n" + note)

    replace_once(
        Path("docs/production.md"),
        "Updated2026-10-31. This is a portable static-hosting procedure. No production deployment has been performed. Source `b803b24` passed [Validate41149485515](https://github.com/AahPlexX/fc/actions/runs/41149485515); TODO records remaining release criteria and docs/verification.md records measured scope. Artifact checks do not establish legal compliance, full accessibility conformance or field performance.",
        "Updated 2026-10-31. This is the production static-hosting procedure for `https://omniconverttool.netlify.app`. Netlify Git continuous deployment is connected to `AahPlexX/fc` branch `main`; Phase22 raises the client to `1.0.1`. The exact deployed artifact still requires `release:verify-host` after this source lands, and permanent `Validate` remains a separate source gate. Artifact checks do not establish legal compliance, full accessibility conformance, physical-device/manual assistive-technology coverage, or field performance.",
    )

    handoff = Path("docs/HANDOFF.md")
    text = handoff.read_text()
    pairs = [
        ('updated_at: "2026-10-31T22:59:07Z"', 'updated_at: "2026-11-01T02:30:00Z"'),
        ('title: "OmniConvert 1.0.0 versioned client update and Netlify handoff"', 'title: "OmniConvert 1.0.1 device-agnostic responsive hardening"'),
        ('summary: "Phase21 establishes 1.0.0 and a deployed-version Update/Cancel prompt; Netlify project is provisioned, while Git linkage and live-host verification remain open."', 'summary: "Phase22 hardens reflow, text scaling, compact landscape dialogs and action wrapping; source validation and exact live-host verification are the remaining gates."'),
        ('resume_focus: "Link AahPlexX/fc main to Netlify project omniconverttool, verify the first deploy, then run release:verify-host against the HTTPS production origin."', 'resume_focus: "Verify the deployed OmniConvert 1.0.1 artifact at https://omniconverttool.netlify.app, then pass permanent Validate and synchronize final Phase22 evidence."'),
    ]
    for old, new in pairs:
        if old not in text:
            raise RuntimeError(f"Missing handoff anchor: {old}")
        text = text.replace(old, new, 1)
    anchor = "Current authority is AGENTS.md, TODO.md, README.md, docs/verification.md and docs/production.md. PRD.md is the unchanged verbatim original brief. Git/CHANGELOG retain older snapshots; previous green CI does not certify newer corrections.\n"
    phase = """

Phase22 (2026-10-31) raises OmniConvert to `1.0.1` and hardens the existing responsive contract rather than adding device-specific layouts. A RED-proven browser regression exposes the prior rem-scaled page minimum at 200% text size on a 320px viewport. The implementation bounds the workbench by available viewport space, uses container-adaptive job actions, wraps long content/modal headers, and improves short-landscape dialog use. New three-engine coverage exercises portrait/landscape, 320–3840px widths, large text, long filenames, target sizing and dialog bounds. Netlify is now named `omniconverttool` and connected to `AahPlexX/fc` main. Live artifact verification and permanent Validate are still pending at this checkpoint; do not infer physical-device/manual accessibility or field-performance certification from lab browser coverage.
"""
    if anchor not in text:
        raise RuntimeError("Missing handoff body anchor")
    handoff.write_text(text.replace(anchor, anchor + phase, 1))


def record_host(report: dict, sha: str) -> None:
    verified = report["verifiedAt"]
    assets = report["verifiedAssets"]
    missing = report["missingAssetChecks"]

    replace_once(
        Path("TODO.md"),
        "**IMPLEMENTED — Phase22 device/viewport-agnostic responsive hardening, awaiting permanent Validate and live-host verification (2026-10-31).**",
        "**HOST VERIFIED — Phase22 device/viewport-agnostic responsive hardening; permanent Validate remains pending (2026-10-31).**",
    )
    replace_once(
        Path("TODO.md"),
        "Next action: confirm the `1.0.1` Netlify deploy for `https://omniconverttool.netlify.app`, run `pnpm release:verify-host -- https://omniconverttool.netlify.app` against the exact clean artifact, then trigger the permanent `Validate` workflow on the synchronized source before marking Phase22 COMPLETE.",
        f"Production host verification passed at `{verified}` against clean implementation `{sha}`: `{assets}` distributable assets matched byte-for-byte with required security/MIME/cache headers and `{missing}` generated missing-asset paths returned real 404s. Next action: trigger permanent `Validate` on the synchronized source before marking Phase22 COMPLETE.",
    )
    replace_once(
        Path("TODO.md"),
        "| 22 | Device/viewport-agnostic responsive hardening | IMPLEMENTED; permanent gate pending | `1.0.1`; RED-proven text-size reflow regression; three-engine responsive suite; live host verification pending. |",
        f"| 22 | Device/viewport-agnostic responsive hardening | HOST VERIFIED; permanent gate pending | `1.0.1`; RED-proven text-size reflow regression; three-engine responsive suite; Netlify host verified for {assets} assets + {missing} real-404 probes. |",
    )

    anchor = "Phase22 implementation candidate (`1.0.1`, 2026-10-31):"
    insert = f"Phase22 live-host result: `{verified}` verified `https://omniconverttool.netlify.app` against clean implementation `{sha}` with `{assets}` distributable artifact hashes/lengths, required CSP/security/MIME/cache behavior, and `{missing}` generated missing-asset 404 checks. The report records `artifactTrackedDirty=false` and `loopbackTest=false`. This closes the prior actual-host contract gap for this artifact; rollback drills, physical devices/manual assistive technology, field CWV and native corresponding-source coverage remain separate.\n\n"
    replace_once(Path("docs/verification.md"), anchor, insert + anchor)

    replace_once(
        Path("docs/production.md"),
        "The exact deployed artifact still requires `release:verify-host` after this source lands, and permanent `Validate` remains a separate source gate.",
        f"`release:verify-host` passed at `{verified}` against clean implementation `{sha}` with `{assets}` exact distributable assets and `{missing}` real-404 probes; permanent `Validate` remains a separate source gate.",
    )

    handoff = Path("docs/HANDOFF.md")
    text = handoff.read_text()
    pairs = [
        ('summary: "Phase22 hardens reflow, text scaling, compact landscape dialogs and action wrapping; source validation and exact live-host verification are the remaining gates."', 'summary: "Phase22 hardens reflow, text scaling, compact landscape dialogs and action wrapping; exact Netlify artifact verification passed and permanent Validate is the remaining source gate."'),
        ('resume_focus: "Verify the deployed OmniConvert 1.0.1 artifact at https://omniconverttool.netlify.app, then pass permanent Validate and synchronize final Phase22 evidence."', 'resume_focus: "Trigger permanent Validate for the synchronized 1.0.1 source, then mark Phase22 COMPLETE and record the run ID without changing runtime behavior."'),
        ("Live artifact verification and permanent Validate are still pending at this checkpoint;", f"Exact live artifact verification passed at `{verified}` for clean implementation `{sha}` ({assets} assets plus {missing} real-404 probes); permanent Validate is still pending at this checkpoint;"),
    ]
    for old, new in pairs:
        if old not in text:
            raise RuntimeError(f"Missing handoff host anchor: {old}")
        text = text.replace(old, new, 1)
    handoff.write_text(text)

    replace_once(
        Path("README.md"),
        "Netlify production is `https://omniconverttool.netlify.app`; the exact deployed artifact is verified separately from the source gate before Phase22 is marked complete.",
        f"Netlify production is `https://omniconverttool.netlify.app`; the exact `1.0.1` artifact passed deployed-host verification at `{verified}` ({assets} assets plus {missing} real-404 probes). Permanent source validation remains the final Phase22 gate.",
    )
    replace_once(
        Path("CHANGELOG.md"),
        "- Netlify project documentation now uses the renamed production project `omniconverttool`; live host verification is performed after the validated source is deployed.",
        f"- Netlify project documentation now uses the renamed production project `omniconverttool`; deployed-host verification passed at `{verified}` for clean implementation `{sha}` across {assets} exact assets plus {missing} generated real-404 probes.",
    )


def main() -> None:
    path = Path("tests/e2e/responsive.spec.ts")
    if path.exists():
        raise RuntimeError("Responsive spec already exists unexpectedly")
    path.write_text(RESPONSIVE_TEST)

    run("pnpm", "build")
    red = run(
        "pnpm", "exec", "playwright", "test", "tests/e2e/responsive.spec.ts",
        "--project=chromium", "--grep", "200% text size", check=False, capture=True,
    )
    print(red.stdout)
    print(red.stderr)
    if red.returncode == 0:
        raise RuntimeError("Expected the pre-fix 200% text-size regression to fail, but it passed.")
    if "200% text size" not in red.stdout + red.stderr:
        raise RuntimeError("RED proof failed for an unexpected reason before the responsive test ran.")

    apply_changes()
    run("pnpm", "audit", "--audit-level=high")
    run("pnpm", "check")
    run("pnpm", "test")
    run("pnpm", "build")
    run("pnpm", "release:check")
    run("pnpm", "release:test")
    run("pnpm", "exec", "playwright", "test", "tests/e2e/responsive.spec.ts")
    run("pnpm", "test:e2e")

    run("git", "config", "user.name", "AahPlexX automation")
    run("git", "config", "user.email", "130876266+AahPlexX@users.noreply.github.com")
    run("git", "rm", ".github/workflows/phase22-responsive.yml", "scripts/phase22-integrate.py")
    run(
        "git", "add", "package.json", "src/styles/tokens.css", "tests/e2e/responsive.spec.ts",
        "AGENTS.md", "TODO.md", "CHANGELOG.md", "README.md", "docs/HANDOFF.md",
        "docs/verification.md", "docs/production.md",
    )
    run("git", "diff", "--cached", "--check")
    run("git", "commit", "-m", "feat: harden device-agnostic responsive UX")
    run("git", "push", "origin", "HEAD:main")
    implementation_sha = run("git", "rev-parse", "HEAD", capture=True).stdout.strip()
    print("Implementation:", implementation_sha)

    run("pnpm", "build")
    run("pnpm", "release:check")

    matched = False
    for attempt in range(90):
        response = run(
            "curl", "-fsS", "-H", "Cache-Control: no-cache",
            "https://omniconverttool.netlify.app/version.json", check=False, capture=True,
        )
        try:
            if response.returncode == 0 and json.loads(response.stdout).get("version") == "1.0.1":
                matched = True
                break
        except json.JSONDecodeError:
            pass
        print(f"Netlify version not ready (attempt {attempt + 1}/90).", flush=True)
        time.sleep(5)
    if not matched:
        raise RuntimeError("Netlify did not expose version 1.0.1 within the bounded verification window.")

    host = run(
        "pnpm", "release:verify-host", "--", "https://omniconverttool.netlify.app",
        capture=True,
    )
    print(host.stderr)
    print(host.stdout)
    report = json.loads(host.stdout)
    for key, value in {
        "origin": "https://omniconverttool.netlify.app",
        "artifactRevision": implementation_sha,
        "artifactTrackedDirty": False,
        "loopbackTest": False,
    }.items():
        if report.get(key) != value:
            raise RuntimeError(f"Unexpected host verification {key}: {report.get(key)!r} != {value!r}")

    Path("release-results/production-host.json").write_text(json.dumps(report, indent=2) + "\n")
    record_host(report, implementation_sha)
    run(
        "git", "add", "TODO.md", "CHANGELOG.md", "README.md", "docs/HANDOFF.md",
        "docs/verification.md", "docs/production.md",
    )
    run("git", "diff", "--cached", "--check")
    run("git", "commit", "-m", "docs: record OmniConvert 1.0.1 production verification")
    run("git", "push", "origin", "HEAD:main")
    docs_sha = run("git", "rev-parse", "HEAD", capture=True).stdout.strip()
    print("Docs checkpoint:", docs_sha)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
